/* دورهمی — کلاینت */
(() => {
'use strict';

// ---------------- ترجمه ----------------
const I18N = {
  fa: {
    brand: 'دورهمی', your_name: 'اسم شما', hokm: 'حکم',
    hokm_desc: 'چهار نفره، دو تیم. هر دست که تیمی ۷ برگ ببرد تمام می‌شود؛ اولین تیمی که به امتیاز هدف برسد برنده است.',
    play_bots: 'بازی با ربات‌ها', create_room: 'ساخت اتاق با دوستان', quick_match: 'بازی آنلاین سریع',
    room_code: 'کد اتاق', join: 'ورود', more_games: 'بازی‌های بعدی', footer: 'دورهمی · نسخه‌ی ۱',
    waiting_room: 'اتاق انتظار', room_code_label: 'کد اتاق — برای دوستانت بفرست', copy_link: 'کپی لینک دعوت',
    start: 'شروع بازی', start_hint: 'جاهای خالی با ربات پر می‌شوند.', wait_host: 'منتظر شروع بازی توسط میزبان…',
    chat: 'گفتگو', send: 'بفرست', reconnecting: 'در حال اتصال دوباره…',
    soon: 'به‌زودی', shelem: 'شلم', poker: 'پوکر', backgammon: 'تخته نرد', crossword: 'جدول', kids: 'بازی‌های کودکان', strategy: 'استراتژی',
    shelem_d: 'کارتی ۴ نفره', poker_d: 'تگزاس هولدم', backgammon_d: 'دو نفره', crossword_d: 'جدول فارسی', kids_d: 'پازل و ساختنی', strategy_d: 'جنگ و فتح',
    sit_here: 'بنشین', add_bot: '+ ربات', remove: 'حذف', host: 'میزبان', bot: 'ربات', you: 'شما',
    team1: 'تیم ۱', team2: 'تیم ۲', team_note: 'روبه‌رویی‌ها یار هم هستند',
    target_label: 'امتیاز برد', visibility: 'نمایش اتاق', public: 'عمومی', private: 'خصوصی',
    us: 'ما', them: 'حریف', to: 'تا', tricks: 'دست',
    picking_hakem: 'تعیین حاکم… اولین آس حاکم است', hakem_is: '{name} حاکم شد 👑',
    choose_trump_title: 'حکم را انتخاب کن', choose_trump_hint: 'این ۵ کارت اول توست. با دیدن آن‌ها خال حکم را تعیین کن.',
    hakem_choosing: '{name} دارد حکم را انتخاب می‌کند…', your_turn: 'نوبت توست', turn_of: 'نوبت {name}',
    S: 'پیک', H: 'دل', D: 'خشت', C: 'گشنیز',
    hand_won_us: 'این دست مال ما شد', hand_won_them: 'این دست را باختیم',
    kot: 'کُت! (+۲)', hakem_kot: 'حاکم کُت! (+۳)', plus1: '+۱ امتیاز',
    match_won: 'برنده شدید! 🏆', match_lost: 'این دور را باختید', rematch: 'یک دور دیگر', leave: 'خروج', back_room: 'برگشت به اتاق',
    menu: 'منو', autoplay_on: 'بازی خودکار: روشن', autoplay_off: 'بازی خودکار: خاموش', sound_on: 'صدا: روشن', sound_off: 'صدا: خاموش', language: 'English',
    close: 'بستن', confirm_leave: 'از بازی خارج شوی؟ جای تو را ربات می‌گیرد.', yes_leave: 'بله، خروج',
    link_copied: 'لینک دعوت کپی شد', joined: '{name} وارد شد', left: '{name} رفت', game_started: 'بازی شروع شد',
    room_not_found: 'اتاقی با این کد پیدا نشد. کد را دوباره بررسی کن.', seat_taken: 'این جا پر است', not_host: 'فقط میزبان می‌تواند این کار را بکند',
    illegal_card: 'باید از همان خال بازی کنی', not_your_turn: 'نوبت تو نیست', error: 'خطا: {e}', slow: 'کمی آهسته‌تر',
    spectating: 'تماشاگر هستی', open_rooms: 'اتاق‌های باز', free_seats: '{n} جای خالی', last_trick: 'دست قبل',
    invite_text: 'بیا حکم بازی کنیم! کد اتاق: {code}', autoplay_badge: 'خودکار', offline: 'قطع',
  },
  en: {
    brand: 'Dorehami', your_name: 'Your name', hokm: 'Hokm',
    hokm_desc: 'Four players, two teams. A hand ends when a team takes 7 tricks; first team to reach the target wins.',
    play_bots: 'Play vs bots', create_room: 'Create room for friends', quick_match: 'Quick online match',
    room_code: 'Room code', join: 'Join', more_games: 'Coming next', footer: 'Dorehami · v1',
    waiting_room: 'Waiting room', room_code_label: 'Room code — send it to friends', copy_link: 'Copy invite link',
    start: 'Start game', start_hint: 'Empty seats are filled with bots.', wait_host: 'Waiting for the host to start…',
    chat: 'Chat', send: 'Send', reconnecting: 'Reconnecting…',
    soon: 'Soon', shelem: 'Shelem', poker: 'Poker', backgammon: 'Backgammon', crossword: 'Crossword', kids: 'Kids games', strategy: 'Strategy',
    shelem_d: '4-player cards', poker_d: "Texas Hold'em", backgammon_d: '2 players', crossword_d: 'Persian crossword', kids_d: 'Puzzles & building', strategy_d: 'Conquer the map',
    sit_here: 'Sit', add_bot: '+ Bot', remove: 'Remove', host: 'Host', bot: 'Bot', you: 'You',
    team1: 'Team 1', team2: 'Team 2', team_note: 'Opposite seats are partners',
    target_label: 'Winning score', visibility: 'Room visibility', public: 'Public', private: 'Private',
    us: 'Us', them: 'Them', to: 'to', tricks: 'tricks',
    picking_hakem: 'Choosing the Hakem… first ace wins', hakem_is: '{name} is the Hakem 👑',
    choose_trump_title: 'Choose trump', choose_trump_hint: 'These are your first 5 cards. Pick the trump suit.',
    hakem_choosing: '{name} is choosing trump…', your_turn: 'Your turn', turn_of: "{name}'s turn",
    S: 'Spades', H: 'Hearts', D: 'Diamonds', C: 'Clubs',
    hand_won_us: 'We won this hand', hand_won_them: 'We lost this hand',
    kot: 'Kot! (+2)', hakem_kot: 'Hakem Kot! (+3)', plus1: '+1 point',
    match_won: 'You won! 🏆', match_lost: 'You lost this round', rematch: 'Play again', leave: 'Leave', back_room: 'Back to room',
    menu: 'Menu', autoplay_on: 'Autoplay: on', autoplay_off: 'Autoplay: off', sound_on: 'Sound: on', sound_off: 'Sound: off', language: 'فارسی',
    close: 'Close', confirm_leave: 'Leave the game? A bot will take your seat.', yes_leave: 'Yes, leave',
    link_copied: 'Invite link copied', joined: '{name} joined', left: '{name} left', game_started: 'Game started',
    room_not_found: 'No room with that code. Check the code and try again.', seat_taken: 'That seat is taken', not_host: 'Only the host can do that',
    illegal_card: 'You must follow the led suit', not_your_turn: 'Not your turn', error: 'Error: {e}', slow: 'Slow down a little',
    spectating: 'You are watching', open_rooms: 'Open rooms', free_seats: '{n} seats free', last_trick: 'Last trick',
    invite_text: "Let's play Hokm! Room code: {code}", autoplay_badge: 'auto', offline: 'offline',
  },
};
const AVATARS = ['🦁', '🐯', '🦊', '🐼', '🐨', '🐸', '🦉', '🐺', '🦄', '🐙', '🐬', '🦅'];
const SUIT_SYM = { S: '♠', H: '♥', D: '♦', C: '♣' };
const RANK = { 11: 'J', 12: 'Q', 13: 'K', 14: 'A' };
const EMOTES = ['👍', '😂', '😮', '😡', '👏', '🔥'];

const store = {
  get: (k, d) => { try { const v = localStorage.getItem('dh_' + k); return v === null ? d : JSON.parse(v); } catch { return d; } },
  set: (k, v) => { try { localStorage.setItem('dh_' + k, JSON.stringify(v)); } catch {} },
};
const S = {
  lang: store.get('lang', 'fa'), sound: store.get('sound', true),
  name: store.get('name', ''), avatar: store.get('avatar', AVATARS[Math.floor(Math.random() * AVATARS.length)]),
  st: null, prev: null, offset: 0, chat: [], unread: 0, sel: null, overlayKind: null,
};
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function t(k, p = {}) {
  let s = (I18N[S.lang] && I18N[S.lang][k]) ?? I18N.fa[k] ?? k;
  for (const [a, b] of Object.entries(p)) s = s.replace('{' + a + '}', b);
  return s;
}
const num = n => S.lang === 'fa' ? Number(n).toLocaleString('fa-IR') : String(n);
const touch = matchMedia('(hover: none)').matches;

// ---------------- صدا ----------------
let actx;
function beep(freqs, dur = .09, type = 'sine', vol = .08) {
  if (!S.sound) return;
  try {
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    let t0 = actx.currentTime;
    for (const f of [].concat(freqs)) {
      const o = actx.createOscillator(), g = actx.createGain();
      o.type = type; o.frequency.value = f; g.gain.setValueAtTime(vol, t0); g.gain.exponentialRampToValueAtTime(.0001, t0 + dur);
      o.connect(g).connect(actx.destination); o.start(t0); o.stop(t0 + dur); t0 += dur * .8;
    }
  } catch {}
}
const sfx = {
  card: () => beep(320 + Math.random() * 60, .05, 'triangle', .06),
  turn: () => beep([660, 880], .1),
  win: () => beep([523, 659, 784, 1046], .14, 'triangle'),
  lose: () => beep([392, 330, 262], .16, 'triangle'),
  trick: () => beep(540, .07, 'sine', .05),
};

// ---------------- اتصال ----------------
const socket = io({ auth: { pid: store.get('pid', '') }, transports: ['websocket', 'polling'] });
const call = (ev, data = {}) => new Promise(res => socket.timeout(8000).emit(ev, data, (err, r) => res(err ? { ok: false, error: 'timeout' } : r)));
async function act(ev, data) {
  const r = await call(ev, data);
  if (!r.ok) toast(I18N.fa[r.error] ? t(r.error) : t('error', { e: r.error }));
  return r;
}

socket.on('connect', () => $('conn').classList.add('hidden'));
socket.on('disconnect', () => $('conn').classList.remove('hidden'));
socket.on('hello', async h => {
  store.set('pid', h.pid);
  socket.auth.pid = h.pid;
  if (S.name || S.avatar) await call('profile', { name: S.name, avatar: S.avatar });
  const code = new URLSearchParams(location.search).get('room');
  if (code && !h.room) {
    history.replaceState(null, '', location.pathname);
    const r = await act('join_room', { code });
    if (!r.ok) showScreen('home');
  } else if (!h.room) { showScreen('home'); loadPublic(); }
});
socket.on('state', st => {
  S.prev = S.st; S.st = st; S.offset = st.now - Date.now();
  render();
});
socket.on('chat_history', list => { S.chat = list.slice(); renderChat(); });
socket.on('chat', m => {
  S.chat.push(m); if (S.chat.length > 80) S.chat.shift();
  renderChat();
  if ($('chatDrawer').classList.contains('hidden') && !m.sys && !m.emote) { S.unread++; badge(); }
  if (m.seat != null && m.seat >= 0) showBubble(m.seat, m.emote || m.text, !!m.emote);
});

// ---------------- ابزار ----------------
let toastT;
function toast(msg) { const el = $('toast'); el.textContent = msg; el.classList.remove('hidden'); clearTimeout(toastT); toastT = setTimeout(() => el.classList.add('hidden'), 2600); }
function showScreen(id) { for (const s of ['home', 'room', 'game']) $(s).classList.toggle('hidden', s !== id); }
function applyLang() {
  document.documentElement.lang = S.lang; document.documentElement.dir = S.lang === 'fa' ? 'rtl' : 'ltr';
  document.querySelectorAll('[data-t]').forEach(el => { el.textContent = t(el.dataset.t); });
  document.querySelectorAll('[data-tp]').forEach(el => { el.placeholder = t(el.dataset.tp); });
  $('langBtn').textContent = S.lang === 'fa' ? 'EN' : 'فا';
  $('soundBtn').textContent = S.sound ? '🔊' : '🔇';
  document.title = t('brand') + ' — ' + t('hokm');
  renderCatalog(); render();
}
function cardHTML(c, cls = '') {
  if (!c) return `<div class="card back ${cls}"></div>`;
  const r = RANK[c.r] || c.r, sym = SUIT_SYM[c.s];
  const trump = S.st?.game_state?.trump === c.s ? ' trumpcard' : '';
  return `<div class="card s-${c.s}${c.r > 10 ? ' face' : ''}${trump} ${cls}" data-id="${c.id}"><b>${r}</b><i>${sym}</i><span class="pip">${sym}</span></div>`;
}
const rel = seat => { const you = S.st && S.st.you >= 0 ? S.st.you : 0; return (seat - you + 4) % 4; };
const myTeam = () => (S.st && S.st.you >= 0 ? S.st.you : 0) % 2;
const seatName = i => { const s = S.st?.seats[i]; return s ? (S.st.you === i ? t('you') : s.name) : '?'; };

// ---------------- خانه ----------------
function renderCatalog() {
  const games = [['shelem', '🃏'], ['poker', '♠️'], ['backgammon', '🎲'], ['crossword', '🔤'], ['kids', '🧩'], ['strategy', '🏰']];
  $('catalog').innerHTML = games.map(([k, ic]) =>
    `<div class="game-tile"><div class="ic">${ic}</div><b>${t(k)}</b><small>${t(k + '_d')} · ${t('soon')}</small></div>`).join('');
}
function renderAvatarPicker() {
  $('avatarPicker').innerHTML = AVATARS.map(a => `<button class="${a === S.avatar ? 'on' : ''}" data-a="${a}">${a}</button>`).join('');
}
async function saveProfile() {
  S.name = $('nameInput').value.trim().slice(0, 18);
  store.set('name', S.name); store.set('avatar', S.avatar);
  await call('profile', { name: S.name || (S.lang === 'fa' ? 'مهمان' : 'Guest'), avatar: S.avatar });
}
async function loadPublic() {
  const r = await call('public_rooms');
  if (!r.ok || !r.rooms.length) { $('publicRooms').innerHTML = ''; return; }
  $('publicRooms').innerHTML = `<div class="muted">${t('open_rooms')}</div>` + r.rooms.map(x =>
    `<div class="pr"><span>${esc(x.players.join('، ') || x.code)} · ${t('free_seats', { n: num(x.free) })}</span><button class="btn small" data-join="${x.code}">${t('join')}</button></div>`).join('');
}

$('nameInput').value = S.name;
$('avatarBtn').textContent = S.avatar;
$('nameInput').addEventListener('change', saveProfile);
$('avatarBtn').onclick = () => { renderAvatarPicker(); $('avatarPicker').classList.toggle('hidden'); };
$('avatarPicker').onclick = e => {
  const a = e.target.closest('button')?.dataset.a; if (!a) return;
  S.avatar = a; $('avatarBtn').textContent = a; $('avatarPicker').classList.add('hidden'); saveProfile();
};
$('langBtn').onclick = () => { S.lang = S.lang === 'fa' ? 'en' : 'fa'; store.set('lang', S.lang); applyLang(); };
$('soundBtn').onclick = () => { S.sound = !S.sound; store.set('sound', S.sound); applyLang(); };
$('soloBtn').onclick = async () => { await saveProfile(); act('create_room', { solo: true, target: store.get('target', 7) }); };
$('createBtn').onclick = async () => { await saveProfile(); act('create_room', { target: store.get('target', 7) }); };
$('quickBtn').onclick = async () => { await saveProfile(); act('quick_match', { game: 'hokm' }); };
$('joinForm').onsubmit = async e => { e.preventDefault(); await saveProfile(); const c = $('codeInput').value.trim(); if (c) act('join_room', { code: c }); };
$('publicRooms').onclick = async e => { const c = e.target.dataset.join; if (c) { await saveProfile(); act('join_room', { code: c }); } };

// ---------------- اتاق انتظار ----------------
function inviteLink() { return location.origin + '/?room=' + S.st.code; }
function renderRoom() {
  const st = S.st;
  $('roomCode').textContent = st.code;
  $('waLink').href = 'https://wa.me/?text=' + encodeURIComponent(t('invite_text', { code: st.code }) + '\n' + inviteLink());
  const slot = i => {
    const s = st.seats[i];
    const teamCls = i % 2 === 0 ? 'team-us' : '';
    if (!s) {
      const hostBtns = st.isHost ? `<div class="tiny"><button data-bot="${i}">${t('add_bot')}</button></div>` : '';
      return `<div class="slot s${rel(i)}"><button class="empty" data-sit="${i}" aria-label="${t('sit_here')}">＋</button><span class="nm">${t('sit_here')}</span>${hostBtns}</div>`;
    }
    const tag = s.kind === 'bot' ? t('bot') : s.isHost ? t('host') : '';
    const canRemove = st.isHost && st.you !== i;
    return `<div class="slot s${rel(i)}"><div class="av ${teamCls} ${s.connected ? '' : 'off'}">${s.avatar}</div>
      <span class="nm">${esc(st.you === i ? t('you') : s.name)}</span>
      <div class="tiny">${tag ? `<span class="cnt">${tag}</span>` : ''}${canRemove ? `<button data-clear="${i}">${t('remove')}</button>` : ''}</div></div>`;
  };
  $('seatGrid').innerHTML = [0, 1, 2, 3].map(slot).join('') + `<div class="teams">${t('team_note')}</div>`;
  const tg = [3, 5, 7, 10].map(n => `<button class="${st.target === n ? 'on' : ''}" data-target="${n}" ${st.isHost ? '' : 'disabled'}>${num(n)}</button>`).join('');
  const vis = st.isHost ? `<div class="seg"><span>${t('visibility')}</span><button class="${!st.isPublic ? 'on' : ''}" data-pub="0">${t('private')}</button><button class="${st.isPublic ? 'on' : ''}" data-pub="1">${t('public')}</button></div>` : '';
  $('roomSettings').innerHTML = `<div class="seg"><span>${t('target_label')}</span>${tg}</div>${vis}`;
  $('startBtn').classList.toggle('hidden', !st.isHost);
  $('startHint').textContent = st.isHost ? t('start_hint') : t('wait_host');
}
$('seatGrid').onclick = e => {
  const b = e.target.closest('button'); if (!b) return;
  if (b.dataset.sit) act('take_seat', { seat: +b.dataset.sit });
  else if (b.dataset.bot) act('add_bot', { seat: +b.dataset.bot });
  else if (b.dataset.clear) act('clear_seat', { seat: +b.dataset.clear });
};
$('roomSettings').onclick = e => {
  const b = e.target.closest('button'); if (!b) return;
  if (b.dataset.target) { store.set('target', +b.dataset.target); act('settings', { target: +b.dataset.target }); }
  if (b.dataset.pub) act('settings', { isPublic: b.dataset.pub === '1' });
};
$('startBtn').onclick = () => act('start');
$('roomLeave').onclick = () => leave();
$('copyLink').onclick = async () => {
  const link = inviteLink();
  if (navigator.share && touch) { try { await navigator.share({ title: t('brand'), text: t('invite_text', { code: S.st.code }), url: link }); return; } catch {} }
  try { await navigator.clipboard.writeText(link); toast(t('link_copied')); } catch { prompt('', link); }
};
async function leave() { await call('leave_room'); S.st = null; S.chat = []; closeOverlay(); showScreen('home'); loadPublic(); }

// ---------------- میز بازی ----------------
function renderScore(g) {
  const us = myTeam(), them = 1 - us;
  $('scoreboard').innerHTML =
    `<div class="team-score us"><span class="dot"></span>${t('us')} <strong>${num(g.scores[us])}</strong><span class="tr">${g.phase !== 'pick_hakem' ? '· ' + num(g.tricksWon[us]) + ' ' + t('tricks') : ''}</span></div>` +
    `<span class="target">${t('to')} ${num(g.target)}</span>` +
    `<div class="team-score them"><span class="dot"></span>${t('them')} <strong>${num(g.scores[them])}</strong><span class="tr">${g.phase !== 'pick_hakem' ? '· ' + num(g.tricksWon[them]) + ' ' + t('tricks') : ''}</span></div>`;
}
function renderSeats(g) {
  const st = S.st;
  for (let i = 0; i < 4; i++) {
    const s = st.seats[i]; const r = rel(i); const el = $('seat' + r);
    if (!s) { el.innerHTML = ''; continue; }
    const isTurn = g && (g.phase === 'play' ? g.turn === i : g.phase === 'choose_trump' && g.hakem === i);
    const crown = g && g.hakem === i && g.phase !== 'pick_hakem' ? '<span class="crown">👑</span>' : '';
    const team = i % 2 === myTeam() ? 'team-us' : '';
    const extra = s.autoplay ? ` · ${t('autoplay_badge')}` : !s.connected ? ` · ${t('offline')}` : '';
    const cnt = r !== 0 && g && g.counts && g.counts[i] ? `<span class="cnt">${num(g.counts[i])} 🂠${extra}</span>` : extra ? `<span class="cnt">${extra}</span>` : '';
    const bubble = el.querySelector('.bubble');
    el.innerHTML = `<div class="av ${team} ${s.connected ? '' : 'off'} ${isTurn ? 'turn' : ''}" data-seat="${i}">${s.avatar}${crown}</div><span class="nm">${esc(r === 0 && st.you === i ? t('you') : s.name)}</span>${cnt}`;
    if (bubble) el.appendChild(bubble);
  }
}
let revealTimer = null, collectTimer = null;
function renderCenter(g) {
  const medal = $('trumpMedal');
  if (g.trump) { medal.textContent = SUIT_SYM[g.trump]; medal.className = 'trump-medal' + ('HD'.includes(g.trump) ? ' red' : ''); medal.title = t(g.trump); }
  else medal.className = 'trump-medal hidden';

  const trickEl = $('trick');
  const prevG = S.prev?.game_state;
  clearTimeout(collectTimer);
  if (g.phase === 'pick_hakem' && g.hakemReveal) {
    if (prevG?.phase !== 'pick_hakem') runReveal(g);
    return;
  }
  clearInterval(revealTimer); revealTimer = null;
  trickEl.className = 'trick';
  const prevIds = new Set((prevG?.trick || []).map(x => x.card.id));
  trickEl.innerHTML = g.trick.map(x => cardHTML(x.card, 'p' + rel(x.seat) + (prevIds.has(x.card.id) ? '' : ' enter') + (g.phase === 'trick_done' && x.seat === g.trickWinner ? ' win' : ''))).join('');
  if (g.trick.length > (prevG?.trick?.length || 0) || (prevG && prevG.trick.length && !g.trick.length)) sfx.card();
  if (g.phase === 'trick_done') collectTimer = setTimeout(() => trickEl.classList.add('go-' + rel(g.trickWinner)), 850);

  let msg = '';
  if (g.phase === 'choose_trump' && g.hakem !== S.st.you) msg = t('hakem_choosing', { name: esc(seatName(g.hakem)) });
  else if (g.phase === 'play' && g.trick.length === 0 && g.turn !== S.st.you) msg = t('turn_of', { name: esc(seatName(g.turn)) });
  else if (g.phase === 'play' && g.turn === S.st.you && g.trick.length === 0) msg = t('your_turn');
  $('centerMsg').innerHTML = msg;
}
function runReveal(g) {
  const trickEl = $('trick'); trickEl.className = 'trick'; trickEl.innerHTML = '';
  $('centerMsg').textContent = t('picking_hakem');
  clearInterval(revealTimer);
  let k = 0; const list = g.hakemReveal;
  const piles = {};
  revealTimer = setInterval(() => {
    if (k >= list.length) {
      clearInterval(revealTimer); revealTimer = null;
      $('centerMsg').textContent = t('hakem_is', { name: seatName(g.hakem) });
      return;
    }
    const { seat, card } = list[k++];
    piles[rel(seat)] = card;
    trickEl.innerHTML = Object.entries(piles).map(([r, c]) => cardHTML(c, 'p' + r + (c.r === 14 ? ' win' : ''))).join('');
    sfx.card();
  }, 150);
}
function renderHand(g) {
  const st = S.st, handEl = $('hand');
  if (st.you < 0) { handEl.innerHTML = `<p class="muted">${t('spectating')}</p>`; return; }
  const hand = g.phase === 'choose_trump' && g.hakem !== st.you ? [] : g.hand;
  const legal = new Set(g.legal);
  const myTurn = g.phase === 'play' && g.turn === st.you;
  handEl.classList.toggle('myturn', myTurn);
  if (S.sel && !legal.has(S.sel)) S.sel = null;
  handEl.innerHTML = hand.map((c, i) => {
    const gap = '';
    const cls = myTurn ? (legal.has(c.id) ? 'legal' : 'dim') : '';
    return cardHTML(c, cls + gap + (S.sel === c.id ? ' sel' : ''));
  }).join('');
  // کارت‌ها همیشه در عرض صفحه جا شوند
  const first = handEl.querySelector('.card');
  if (first && hand.length > 1) {
    const cw = first.getBoundingClientRect().width, avail = handEl.clientWidth - 16;
    const ov = Math.min(-cw * 0.28, (avail - cw) / (hand.length - 1) - cw);
    handEl.style.setProperty('--ov', ov + 'px');
  }
  const prevG = S.prev?.game_state;
  if (myTurn && !(prevG && prevG.phase === 'play' && prevG.turn === st.you)) sfx.turn();
}
$('hand').addEventListener('click', e => {
  const el = e.target.closest('.card.legal'); if (!el) return;
  const id = el.dataset.id;
  if (touch && S.sel !== id) { S.sel = id; renderHand(S.st.game_state); return; }
  S.sel = null;
  el.style.visibility = 'hidden';
  act('play', { card: id });
});

function renderOverlays(g) {
  const st = S.st, prevG = S.prev?.game_state;
  if (g.phase === 'choose_trump' && g.hakem === st.you) {
    if (S.overlayKind !== 'trump') openTrump(g);
    return;
  }
  if (g.phase === 'hand_over' && prevG?.phase !== 'hand_over') { openHandOver(g); return; }
  if (g.phase === 'match_over') { if (S.overlayKind !== 'match') openMatchOver(g); return; }
  if (['trump', 'hand', 'match'].includes(S.overlayKind)) closeOverlay();
}
function openOverlay(html, kind) { S.overlayKind = kind; $('sheet').innerHTML = html; $('overlay').classList.remove('hidden'); }
function closeOverlay() { S.overlayKind = null; $('overlay').classList.add('hidden'); }
$('overlay').addEventListener('click', e => { if (e.target.id === 'overlay' && S.overlayKind === 'menu') closeOverlay(); });

function openTrump(g) {
  const five = g.hand.map(c => cardHTML(c)).join('');
  const btns = ['S', 'H', 'D', 'C'].map(s => `<button class="${'HD'.includes(s) ? 'red' : ''}" data-suit="${s}">${SUIT_SYM[s]}<span>${t(s)}</span></button>`).join('');
  openOverlay(`<h3>${t('choose_trump_title')} 👑</h3><p class="muted">${t('choose_trump_hint')}</p><div class="five">${five}</div><div class="suit-grid">${btns}</div>`, 'trump');
  $('sheet').querySelector('.suit-grid').onclick = async e => {
    const b = e.target.closest('button'); if (!b) return;
    const r = await act('choose_trump', { suit: b.dataset.suit });
    if (r.ok) closeOverlay();
  };
}
function openHandOver(g) {
  const h = g.lastHand; if (!h) return;
  const won = h.winTeam === myTeam();
  const kind = h.kind === 'hakem_kot' ? t('hakem_kot') : h.kind === 'kot' ? t('kot') : t('plus1');
  won ? sfx.win() : sfx.lose();
  const us = myTeam();
  openOverlay(`<div class="center"><h3>${won ? t('hand_won_us') : t('hand_won_them')}</h3>
    <div class="big-result">${kind}</div>
    <div class="score-line"><span>${t('us')} <b>${num(g.scores[us])}</b></span><span>${t('them')} <b>${num(g.scores[1 - us])}</b></span></div>
    <p class="muted">${t('to')} ${num(g.target)}</p></div>`, 'hand');
}
function openMatchOver(g) {
  const won = g.matchWinner === myTeam();
  won ? sfx.win() : sfx.lose();
  const us = myTeam();
  const host = S.st.isHost;
  openOverlay(`<div class="center"><div class="big-result">${won ? t('match_won') : t('match_lost')}</div>
    <div class="score-line"><span>${t('us')} <b>${num(g.scores[us])}</b></span><span>${t('them')} <b>${num(g.scores[1 - us])}</b></span></div></div>
    <div class="row">${host ? `<button class="btn primary" id="rematchBtn">${t('rematch')}</button>` : ''}
    ${host ? `<button class="btn" id="backRoomBtn">${t('back_room')}</button>` : ''}
    <button class="btn" id="leaveBtn2">${t('leave')}</button></div>`, 'match');
  $('rematchBtn')?.addEventListener('click', () => act('start'));
  $('backRoomBtn')?.addEventListener('click', () => act('back_to_lobby'));
  $('leaveBtn2').onclick = () => leave();
}
function openMenu() {
  const me = S.st.seats[S.st.you];
  const auto = me?.autoplay;
  openOverlay(`<h3>${t('menu')}</h3><div class="menu">
    <button class="btn" id="mAuto">${auto ? t('autoplay_on') : t('autoplay_off')}</button>
    <button class="btn" id="mSound">${S.sound ? t('sound_on') : t('sound_off')}</button>
    <button class="btn" id="mLang">${t('language')}</button>
    <button class="btn" id="mInvite">${t('copy_link')} · ${S.st.code}</button>
    <button class="btn" id="mLeave">${t('leave')}</button>
    <button class="btn primary" id="mClose">${t('close')}</button></div>`, 'menu');
  $('mAuto').onclick = async () => { await act('autoplay', { value: !auto }); closeOverlay(); };
  $('mSound').onclick = () => { S.sound = !S.sound; store.set('sound', S.sound); applyLang(); openMenu(); };
  $('mLang').onclick = () => { S.lang = S.lang === 'fa' ? 'en' : 'fa'; store.set('lang', S.lang); applyLang(); openMenu(); };
  $('mInvite').onclick = () => $('copyLink').click();
  $('mLeave').onclick = () => {
    openOverlay(`<h3>${t('confirm_leave')}</h3><div class="row"><button class="btn primary" id="yl">${t('yes_leave')}</button><button class="btn" id="nl">${t('close')}</button></div>`, 'menu');
    $('yl').onclick = () => leave();
    $('nl').onclick = closeOverlay;
  };
  $('mClose').onclick = closeOverlay;
}
$('menuBtn').onclick = openMenu;

// تایمر نوبت
setInterval(() => {
  const st = S.st; if (!st || !st.deadline) return;
  const left = Math.max(0, st.deadline - (Date.now() + S.offset));
  const p = left / (st.turnSeconds * 1000);
  document.querySelectorAll('.av.turn').forEach(el => el.style.setProperty('--p', p.toFixed(3)));
}, 200);

// ---------------- گفتگو ----------------
function badge() { const b = $('chatBadge'); b.textContent = num(S.unread); b.classList.toggle('hidden', !S.unread); }
function renderChat() {
  const log = $('chatLog');
  log.innerHTML = S.chat.map(m => m.sys
    ? `<div class="sys">${esc(t(m.key, m.params || {}))}</div>`
    : `<div class="m"><b>${m.avatar || ''} ${esc(m.name)}</b>${esc(m.emote || m.text)}</div>`).join('');
  log.scrollTop = log.scrollHeight;
}
function showBubble(seat, text, emo) {
  if (!S.st || S.st.status === 'waiting') return;
  const el = $('seat' + rel(seat)); if (!el) return;
  el.querySelector('.bubble')?.remove();
  const b = document.createElement('div'); b.className = 'bubble' + (emo ? ' emo' : ''); b.textContent = text;
  el.appendChild(b); setTimeout(() => b.remove(), 3200);
}
$('chatBtn').onclick = () => { $('chatDrawer').classList.remove('hidden'); S.unread = 0; badge(); renderChat(); setTimeout(() => $('chatInput').focus(), 50); };
$('chatClose').onclick = () => $('chatDrawer').classList.add('hidden');
$('chatForm').onsubmit = e => { e.preventDefault(); const v = $('chatInput').value.trim(); if (!v) return; $('chatInput').value = ''; act('chat', { text: v }); };
$('emotes').innerHTML = EMOTES.map(e => `<button data-e="${e}">${e}</button>`).join('');
$('emotes').onclick = e => { const v = e.target.dataset.e; if (v) act('chat', { emote: v }); };

// ---------------- رندر اصلی ----------------
function render() {
  const st = S.st;
  if (!st) return;
  if (st.status === 'waiting') { closeOverlayIfGame(); showScreen('room'); renderRoom(); return; }
  showScreen('game');
  const g = st.game_state; if (!g) return;
  renderScore(g); renderSeats(g); renderCenter(g); renderHand(g); renderOverlays(g);
}
function closeOverlayIfGame() { if (['trump', 'hand', 'match'].includes(S.overlayKind)) closeOverlay(); }

window.addEventListener('resize', () => { if (S.st?.game_state) renderHand(S.st.game_state); });
applyLang();
})();
