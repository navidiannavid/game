const { HokmGame } = require('../server/games/hokm/engine');
const bot = require('../server/games/hokm/bot');
function rnd(g,s){const l=g.legalCards(s);return l[Math.floor(Math.random()*l.length)].id;}
function runMatch(smartTeam){
  const g=new HokmGame(); g.startMatch(); let hands=0;
  while(g.phase!=='match_over'){
    if(g.phase==='pick_hakem'||g.phase==='hand_over'){g.startHand();hands++;
      if(g.hands[g.hakem].length!==5) throw 'deal5';}
    else if(g.phase==='choose_trump'){g.chooseTrump(g.hakem, bot.chooseTrump(g.hands[g.hakem]));
      const tot=g.hands.reduce((a,h)=>a+h.length,0); if(tot!==52||g.hands.some(h=>h.length!==13)) throw 'deal13';}
    else if(g.phase==='play'){const s=g.turn; const id = (smartTeam===null||s%2===smartTeam)?bot.chooseCard(g,s):rnd(g,s); g.play(s,id);}
    else if(g.phase==='trick_done'){g.collectTrick(); if(g.tricksWon[0]+g.tricksWon[1]>13) throw 'tricks';}
  }
  return {w:g.matchWinner,hands};
}
let N=3000, wins=0, t=Date.now();
for(let i=0;i<N;i++){ if(runMatch(0).w===0) wins++; }
console.log('smart team0 vs random win%', (100*wins/N).toFixed(1));
wins=0; for(let i=0;i<N;i++){ if(runMatch(null).w===0) wins++; }
console.log('bot vs bot team0 win%', (100*wins/N).toFixed(1), 'ms', Date.now()-t);
