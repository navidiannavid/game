// 4 real clients join one room and play a full match through the server
process.env.PORT=3999;
const {server}=require('../server/index');
const {io}=require('socket.io-client');
const bot=require('../server/games/hokm/bot');
const {HokmGame}=require('../server/games/hokm/engine');
const URL='http://localhost:3999';
const mk=(pid)=>io(URL,{auth:{pid},transports:['websocket']});
const call=(s,ev,d)=>new Promise(r=>s.emit(ev,d,r));
(async()=>{
  const cs=[0,1,2,3].map(i=>mk('testplayer-'+i));
  await Promise.all(cs.map(c=>new Promise(r=>c.on('hello',r))));
  for(let i=0;i<4;i++) await call(cs[i],'profile',{name:'P'+i});
  const {code}=await call(cs[0],'create_room',{target:3});
  for(let i=1;i<4;i++){const r=await call(cs[i],'join_room',{code}); if(!r.ok) throw r;}
  let done=false, plays=0, errors=0, last={};
  cs.forEach((c,i)=>c.on('state',async st=>{
    last[i]=st; const g=st.game_state; if(!g) return;
    if(g.phase==='match_over'&&!done&&i===0){done=true;console.log('MATCH OVER winner team',g.matchWinner,'scores',g.scores,'plays',plays,'errors',errors);
      // test reconnect
      cs[2].disconnect(); setTimeout(()=>{const c=mk('testplayer-2'); c.on('state',s=>{ if(!c.ok){c.ok=1;console.log('reconnect seat',s.you,'status',s.status);process.exit(0);} });},300);}
    if(g.phase==='choose_trump'&&g.hakem===st.you&&g.hand.length===5){const r=await call(c,'choose_trump',{suit:bot.chooseTrump(g.hand)}); if(!r.ok)errors++;}
    if(g.phase==='play'&&g.turn===st.you&&g.legal.length){
      // also try an illegal move occasionally
      if(Math.random()<0.05 && g.legal.length<g.hand.length){const bad=g.hand.find(x=>!g.legal.includes(x.id)); const r=await call(c,'play',{card:bad.id}); if(r.ok) {console.log('ILLEGAL ACCEPTED');process.exit(1);} }
      const r=await call(c,'play',{card:g.legal[Math.floor(Math.random()*g.legal.length)]}); if(r.ok)plays++; }
  }));
  await call(cs[0],'start',{});
  setTimeout(()=>{console.log('TIMEOUT',JSON.stringify(last[0]?.game_state?.phase));process.exit(1)},240000);
})();
