// هوش مصنوعی ربات حکم — فقط از اطلاعات مجاز استفاده می‌کند (دست خودش + کارت‌های بازی‌شده)
const { SUITS, beats, trickWinnerIndex, makeDeck } = require('./engine');

const FULL = makeDeck();

// انتخاب حکم از روی ۵ کارت اول
function chooseTrump(hand5) {
  let best = null, bestScore = -1;
  for (const s of SUITS) {
    const cs = hand5.filter(c => c.s === s);
    if (!cs.length) continue;
    const score = cs.length * 10 + cs.reduce((a, c) => a + (c.r >= 11 ? c.r - 8 : c.r / 4), 0);
    if (score > bestScore) { bestScore = score; best = s; }
  }
  return best || 'S';
}

function unknownCards(g, seat) {
  const seen = new Set();
  for (const c of g.played) seen.add(c.id);
  for (const t of g.trick) seen.add(t.card.id);
  for (const c of g.hands[seat]) seen.add(c.id);
  return FULL.filter(c => !seen.has(c.id));
}

const low = arr => arr.reduce((a, c) => (c.r < a.r ? c : a));
const high = arr => arr.reduce((a, c) => (c.r > a.r ? c : a));

function chooseCard(g, seat) {
  const legal = g.legalCards(seat);
  if (legal.length === 1) return legal[0].id;
  const trump = g.trump;
  const hand = g.hands[seat];
  const unknown = unknownCards(g, seat);
  const isMaster = c => !unknown.some(u => u.s === c.s && u.r > c.r);
  const trumpsOut = unknown.filter(u => u.s === trump).length;
  const opps = [(seat + 1) % 4, (seat + 3) % 4];
  const oppVoid = s => opps.some(o => g.voids[o].includes(s));
  const partner = (seat + 2) % 4;

  // ---- شروع دست (لید) ----
  if (g.trick.length === 0) {
    const nonTrump = legal.filter(c => c.s !== trump);
    const myTrumps = legal.filter(c => c.s === trump);
    // اگر حکم زیاد داریم و تک‌خال حکم دستمان است، حکم‌ها را بکشیم
    if (myTrumps.length >= 4 && trumpsOut > 0) {
      const m = myTrumps.filter(isMaster);
      if (m.length) return high(m).id;
    }
    // کارت برنده‌ی مطمئن (تک‌خال) در خال غیرحکم — به شرطی که حریف بُر نزند
    const safeMasters = nonTrump.filter(c => isMaster(c) && !(oppVoid(c.s) && trumpsOut > 0));
    if (safeMasters.length) return high(safeMasters).id;
    // خالی که یار در آن خالی است و حریف نیست — یار بُر بزند
    const partnerRuff = nonTrump.filter(c => g.voids[partner].includes(c.s) && !oppVoid(c.s));
    if (partnerRuff.length && trumpsOut > 0) return low(partnerRuff).id;
    if (nonTrump.length) {
      // کمترین کارت از بلندترین خال
      const bySuit = {};
      for (const c of nonTrump) (bySuit[c.s] = bySuit[c.s] || []).push(c);
      const suits = Object.keys(bySuit).sort((a, b) => bySuit[b].length - bySuit[a].length);
      // از خالی که حریف در آن خالی است دوری کن
      const pick = suits.find(s => !oppVoid(s)) || suits[0];
      return low(bySuit[pick]).id;
    }
    const m = myTrumps.filter(isMaster);
    return (m.length ? high(m) : low(myTrumps)).id;
  }

  // ---- پیروی ----
  const led = g.trick[0].card.s;
  const wi = trickWinnerIndex(g.trick, trump);
  const winning = g.trick[wi];
  const partnerWinning = winning.seat === partner;
  const isLast = g.trick.length === 3;
  const winningSafe = isLast || (winning.card.s === trump && led !== trump
    ? !unknown.some(u => u.s === trump && u.r > winning.card.r) || !g.voids[(seat + 1) % 4].includes(led)
    : isMaster(winning.card) && !(g.voids[(seat + 1) % 4].includes(led) && trumpsOut > 0));
  const canBeat = legal.filter(c => beats(c, winning.card, led, trump));
  const following = legal[0].s === led && legal.every(c => c.s === led);

  if (partnerWinning && winningSafe) {
    // یار برنده است: کمترین کارت (اگر خالی هستیم، کم‌ارزش‌ترین غیرحکم)
    const nonTrump = legal.filter(c => c.s !== trump);
    return low(nonTrump.length ? nonTrump : legal).id;
  }

  if (following) {
    if (canBeat.length) {
      if (isLast) return low(canBeat).id;
      const masters = canBeat.filter(isMaster);
      const nextOppVoid = g.voids[(seat + 1) % 4].includes(led) && trumpsOut > 0 && led !== trump;
      if (masters.length && !nextOppVoid) return low(masters).id;
      if (g.trick.length === 2 && !partnerWinning) return high(canBeat).id;
      if (partnerWinning) return low(legal).id;
      return (masters.length ? low(masters) : low(legal)).id;
    }
    return low(legal).id;
  }

  // خال نداریم: بُر بزنیم یا دور بریزیم
  const trumpsThatWin = canBeat.filter(c => c.s === trump);
  if (trumpsThatWin.length && !(partnerWinning && winningSafe)) {
    // اگر یار برنده است و هنوز نفر آخر نیستیم، بُر نزن مگر کارت یار ضعیف باشد
    if (partnerWinning && !isLast && isMaster(winning.card)) {
      const nt = legal.filter(c => c.s !== trump);
      if (nt.length) return low(nt).id;
    }
    return low(trumpsThatWin).id;
  }
  const discard = legal.filter(c => c.s !== trump);
  if (discard.length) {
    // کارت ضعیف از کوتاه‌ترین خال، و تک‌خال‌ها را نگه دار
    const nonMaster = discard.filter(c => !isMaster(c));
    const pool = nonMaster.length ? nonMaster : discard;
    const count = s => hand.filter(c => c.s === s).length;
    return pool.slice().sort((a, b) => (a.r - b.r) || (count(a.s) - count(b.s)))[0].id;
  }
  return low(legal).id;
}

module.exports = { chooseTrump, chooseCard };
