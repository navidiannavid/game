// موتور بازی حکم — قوانین کامل، کاملاً سمت سرور
// Hokm engine. Seats 0..3, teams: (0,2) and (1,3). Play order: seat+1 (counter-clockwise on screen).
const crypto = require('crypto');

const SUITS = ['S', 'H', 'D', 'C']; // پیک، دل، خشت، گشنیز
const RANKS = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]; // 11=J 12=Q 13=K 14=A

function cardId(c) { return c.s + c.r; }
function makeDeck() {
  const d = [];
  for (const s of SUITS) for (const r of RANKS) d.push({ s, r, id: s + r });
  return d;
}
function shuffle(a) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = crypto.randomInt(i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
const SUIT_ORDER = { S: 0, H: 1, C: 2, D: 3 }; // alternate colors in hand
function sortHand(h, trump) {
  return h.sort((a, b) => {
    const sa = a.s === trump ? -1 : SUIT_ORDER[a.s];
    const sb = b.s === trump ? -1 : SUIT_ORDER[b.s];
    return sa !== sb ? sa - sb : b.r - a.r;
  });
}
// does card a beat card b, given led suit and trump?
function beats(a, b, led, trump) {
  if (a.s === b.s) return a.r > b.r;
  if (a.s === trump) return true;
  if (b.s === trump) return false;
  if (a.s === led) return true;
  return false;
}
function trickWinnerIndex(trick, trump) {
  const led = trick[0].card.s;
  let w = 0;
  for (let i = 1; i < trick.length; i++) if (beats(trick[i].card, trick[w].card, led, trump)) w = i;
  return w;
}

class HokmGame {
  constructor(opts = {}) {
    this.target = opts.target || 7; // امتیاز برد مسابقه
    this.scores = [0, 0];
    this.hakem = null;
    this.phase = 'idle';
    this.handNo = 0;
    this.hands = [[], [], [], []];
    this.trick = [];
    this.trump = null;
    this.tricksWon = [0, 0];
    this.played = []; // cards from completed tricks
    this.lastTrick = null;
    this.lastHand = null;
    this.hakemReveal = null;
    this.turn = null;
    this.trickWinner = null;
    this.voids = [[], [], [], []]; // suits each seat has shown void in (for AI + no cheating: public info)
  }

  // تعیین حاکم: کارت‌ها یکی‌یکی پخش می‌شوند تا اولین آس
  startMatch(firstHakem = null) {
    this.scores = [0, 0];
    this.handNo = 0;
    this.lastHand = null;
    if (firstHakem === null) {
      const deck = shuffle(makeDeck());
      const reveal = [];
      let seat = crypto.randomInt(4);
      for (const c of deck) {
        reveal.push({ seat, card: c });
        if (c.r === 14) break;
        seat = (seat + 1) % 4;
      }
      this.hakemReveal = reveal;
      this.hakem = reveal[reveal.length - 1].seat;
    } else {
      this.hakemReveal = null;
      this.hakem = firstHakem;
    }
    this.phase = 'pick_hakem';
  }

  startHand() {
    this.handNo++;
    this.deck = shuffle(makeDeck());
    this.hands = [[], [], [], []];
    this.trick = [];
    this.trump = null;
    this.tricksWon = [0, 0];
    this.played = [];
    this.lastTrick = null;
    this.trickWinner = null;
    this.voids = [[], [], [], []];
    // حاکم ۵ کارت اول را می‌گیرد و حکم را انتخاب می‌کند
    this.hands[this.hakem] = this.deck.splice(0, 5);
    sortHand(this.hands[this.hakem], null);
    this.phase = 'choose_trump';
    this.turn = this.hakem;
  }

  chooseTrump(seat, suit) {
    if (this.phase !== 'choose_trump') throw new Error('not_choose_phase');
    if (seat !== this.hakem) throw new Error('not_hakem');
    if (!SUITS.includes(suit)) throw new Error('bad_suit');
    this.trump = suit;
    // پخش بقیه: ۵ تایی برای بقیه، سپس ۴ تا ۴ تا
    for (let k = 1; k <= 3; k++) this.hands[(this.hakem + k) % 4].push(...this.deck.splice(0, 5));
    for (let round = 0; round < 2; round++)
      for (let k = 0; k < 4; k++) this.hands[(this.hakem + k) % 4].push(...this.deck.splice(0, 4));
    for (const h of this.hands) sortHand(h, this.trump);
    this.phase = 'play';
    this.turn = this.hakem;
  }

  legalCards(seat) {
    const hand = this.hands[seat];
    if (this.phase !== 'play' || this.trick.length === 0) return hand.slice();
    const led = this.trick[0].card.s;
    const follow = hand.filter(c => c.s === led);
    return follow.length ? follow : hand.slice();
  }

  play(seat, id) {
    if (this.phase !== 'play') throw new Error('not_play_phase');
    if (seat !== this.turn) throw new Error('not_your_turn');
    const legal = this.legalCards(seat);
    const card = legal.find(c => c.id === id);
    if (!card) throw new Error('illegal_card');
    const hand = this.hands[seat];
    hand.splice(hand.findIndex(c => c.id === id), 1);
    if (this.trick.length && card.s !== this.trick[0].card.s && !this.voids[seat].includes(this.trick[0].card.s))
      this.voids[seat].push(this.trick[0].card.s);
    this.trick.push({ seat, card });
    if (this.trick.length === 4) {
      const w = this.trick[trickWinnerIndex(this.trick, this.trump)].seat;
      this.trickWinner = w;
      this.phase = 'trick_done';
      this.turn = null;
    } else {
      this.turn = (seat + 1) % 4;
    }
    return card;
  }

  // بعد از نمایش دست برنده، دست جمع می‌شود
  collectTrick() {
    if (this.phase !== 'trick_done') return;
    const w = this.trickWinner;
    this.tricksWon[w % 2]++;
    this.lastTrick = { cards: this.trick.slice(), winner: w };
    for (const t of this.trick) this.played.push(t.card);
    this.trick = [];
    this.trickWinner = null;
    const t = w % 2;
    if (this.tricksWon[t] === 7) return this.endHand(t);
    this.phase = 'play';
    this.turn = w;
  }

  endHand(winTeam) {
    const loseTeam = 1 - winTeam;
    const hakemTeam = this.hakem % 2;
    const kot = this.tricksWon[loseTeam] === 0;
    let pts = 1;
    let kind = 'normal';
    if (kot) {
      if (winTeam !== hakemTeam) { pts = 3; kind = 'hakem_kot'; } // حاکم کُت
      else { pts = 2; kind = 'kot'; }
    }
    this.scores[winTeam] += pts;
    this.lastHand = { winTeam, pts, kind, tricks: this.tricksWon.slice(), hakem: this.hakem, trump: this.trump };
    this.turn = null;
    // حاکم بعدی: اگر تیم حاکم ببرد حاکم می‌ماند، وگرنه نفر بعدی حاکم می‌شود
    if (winTeam !== hakemTeam) this.hakem = (this.hakem + 1) % 4;
    if (this.scores[winTeam] >= this.target) {
      this.phase = 'match_over';
      this.matchWinner = winTeam;
    } else {
      this.phase = 'hand_over';
    }
  }

  // نمای بازی برای هر بازیکن — کارت‌های دیگران مخفی می‌ماند
  viewFor(seat) {
    return {
      phase: this.phase,
      hakem: this.hakem,
      trump: this.trump,
      turn: this.turn,
      scores: this.scores,
      target: this.target,
      tricksWon: this.tricksWon,
      trick: this.trick,
      trickWinner: this.trickWinner,
      lastTrick: this.lastTrick,
      lastHand: this.lastHand,
      handNo: this.handNo,
      matchWinner: this.matchWinner ?? null,
      hakemReveal: this.phase === 'pick_hakem' ? this.hakemReveal : null,
      counts: this.hands.map(h => h.length),
      hand: seat != null && seat >= 0 ? this.hands[seat] : [],
      legal: seat != null && seat === this.turn && this.phase === 'play' ? this.legalCards(seat).map(c => c.id) : [],
    };
  }
}

module.exports = { HokmGame, SUITS, beats, trickWinnerIndex, makeDeck, cardId };
