// سرور «دورهمی» — اتاق‌ها، بازی آنلاین، ربات‌ها
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const express = require('express');
const { Server } = require('socket.io');
const { HokmGame } = require('./games/hokm/engine');
const hokmBot = require('./games/hokm/bot');

const PORT = process.env.PORT || 3000;
const TURN_SECONDS = 30;
const BOT_NAMES = ['آرش', 'سارا', 'کاوه', 'مینا', 'بهرام', 'نگار', 'رستم', 'پریا', 'داریوش', 'لیلا', 'سهراب', 'شیرین'];
const AVATARS = ['🦁', '🐯', '🦊', '🐼', '🐨', '🐸', '🦉', '🐺', '🦄', '🐙', '🐬', '🦅'];

const app = express();
app.use(express.static(path.join(__dirname, '..', 'public'), { maxAge: '1h', index: 'index.html' }));
app.get('/health', (_, res) => res.json({ ok: true, rooms: rooms.size }));
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' }, pingInterval: 10000, pingTimeout: 8000 });

const rooms = new Map(); // code -> room
const players = new Map(); // pid -> { name, avatar, room, sockets:Set }

const clean = (s, n = 18) => String(s || '').replace(/[<>\n\r\t]/g, '').trim().slice(0, n);
function newCode() {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let c;
  do { c = Array.from({ length: 5 }, () => A[crypto.randomInt(A.length)]).join(''); } while (rooms.has(c));
  return c;
}
function botSeat(room) {
  const used = new Set(room.seats.filter(Boolean).map(s => s.name));
  const free = BOT_NAMES.filter(n => !used.has(n));
  const name = free[crypto.randomInt(free.length)] || 'ربات';
  return { kind: 'bot', name, avatar: '🤖' };
}

function createRoom(hostPid, { isPublic = false, target = 7, game = 'hokm' } = {}) {
  const room = {
    code: newCode(), game, host: hostPid, isPublic, status: 'waiting',
    seats: [null, null, null, null], spectators: new Set(), chat: [],
    engine: null, timer: null, deadline: null, target: [3, 5, 7, 10].includes(+target) ? +target : 7,
    lastActive: Date.now(), createdAt: Date.now(),
  };
  rooms.set(room.code, room);
  return room;
}

function seatOf(room, pid) { return room.seats.findIndex(s => s && s.kind === 'human' && s.pid === pid); }
function humans(room) { return room.seats.filter(s => s && s.kind === 'human'); }

function roomView(room, pid) {
  const you = seatOf(room, pid);
  return {
    code: room.code, game: room.game, status: room.status, isPublic: room.isPublic, target: room.target,
    isHost: room.host === pid, you,
    seats: room.seats.map((s, i) => s && {
      kind: s.kind, name: s.name, avatar: s.avatar, connected: s.kind === 'bot' ? true : !!s.connected,
      isHost: s.kind === 'human' && s.pid === room.host, autoplay: !!s.autoplay, seat: i,
    }),
    spectators: room.spectators.size,
    deadline: room.deadline, now: Date.now(), turnSeconds: TURN_SECONDS,
    game_state: room.engine ? room.engine.viewFor(you) : null,
  };
}

function broadcast(room) {
  room.lastActive = Date.now();
  const targets = new Set([...humans(room).map(s => s.pid), ...room.spectators]);
  for (const pid of targets) io.to('p:' + pid).emit('state', roomView(room, pid));
}

function sysChat(room, key, params = {}) {
  const msg = { sys: true, key, params, t: Date.now() };
  room.chat.push(msg); if (room.chat.length > 60) room.chat.shift();
  io.to('r:' + room.code).emit('chat', msg);
}

// ---------- زمان‌بندی نوبت‌ها ----------
function schedule(room) {
  clearTimeout(room.timer); room.timer = null; room.deadline = null;
  const g = room.engine;
  if (!g || room.status !== 'playing') return;
  // اگر هیچ انسانی وصل نیست، بازی متوقف می‌ماند تا برگردد
  if (!humans(room).some(h => h.connected) && !room.spectators.size) return;
  const later = (ms, fn) => { room.timer = setTimeout(() => { try { fn(); } catch (e) { console.error(e); } broadcast(room); schedule(room); }, ms); };
  switch (g.phase) {
    case 'pick_hakem': return later(Math.min(2200 + (g.hakemReveal?.length || 0) * 160, 7000), () => g.startHand());
    case 'trick_done': return later(1400, () => g.collectTrick());
    case 'hand_over': return later(5000, () => g.startHand());
    case 'match_over': room.status = 'finished'; return;
  }
  const seat = g.phase === 'choose_trump' ? g.hakem : g.turn;
  const s = room.seats[seat];
  const auto = () => botAct(room, seat);
  if (!s || s.kind === 'bot') return later(g.phase === 'choose_trump' ? 1400 : 650 + crypto.randomInt(700), auto);
  if (!s.connected || s.autoplay) return later(1200, auto);
  room.deadline = Date.now() + TURN_SECONDS * 1000;
  later(TURN_SECONDS * 1000, () => { s.missed = (s.missed || 0) + 1; if (s.missed >= 2) s.autoplay = true; auto(); });
}

function botAct(room, seat) {
  const g = room.engine;
  if (g.phase === 'choose_trump' && g.hakem === seat) g.chooseTrump(seat, hokmBot.chooseTrump(g.hands[seat]));
  else if (g.phase === 'play' && g.turn === seat) g.play(seat, hokmBot.chooseCard(g, seat));
}

function startGame(room) {
  for (let i = 0; i < 4; i++) if (!room.seats[i]) room.seats[i] = botSeat(room);
  room.engine = new HokmGame({ target: room.target });
  room.engine.startMatch();
  room.status = 'playing';
  for (const s of room.seats) if (s && s.kind === 'human') { s.missed = 0; s.autoplay = false; }
  sysChat(room, 'game_started');
  broadcast(room); schedule(room);
}

function leaveRoom(pid) {
  const p = players.get(pid);
  if (!p || !p.room) return;
  const room = rooms.get(p.room);
  p.room = null;
  for (const sid of p.sockets) io.sockets.sockets.get(sid)?.leave('r:' + room?.code);
  if (!room) return;
  room.spectators.delete(pid);
  const i = seatOf(room, pid);
  if (i >= 0) {
    const name = room.seats[i].name;
    if (room.status === 'waiting') room.seats[i] = null;
    else room.seats[i] = { ...botSeat(room), vacated: true };
    sysChat(room, 'left', { name });
  }
  if (!humans(room).length && !room.spectators.size) { clearTimeout(room.timer); rooms.delete(room.code); return; }
  if (room.host === pid) {
    const h = humans(room)[0];
    if (h) room.host = h.pid;
  }
  broadcast(room); schedule(room);
}

function joinRoom(pid, room) {
  const p = players.get(pid);
  if (p.room && p.room !== room.code) leaveRoom(pid);
  p.room = room.code;
  for (const sid of p.sockets) io.sockets.sockets.get(sid)?.join('r:' + room.code);
  let i = seatOf(room, pid);
  if (i >= 0) { room.seats[i].connected = true; room.seats[i].name = p.name; room.seats[i].avatar = p.avatar; }
  else {
    const human = { kind: 'human', pid, name: p.name, avatar: p.avatar, connected: true };
    if (room.status === 'waiting') i = room.seats.findIndex(s => !s);
    else i = room.seats.findIndex(s => s && s.vacated);
    if (i >= 0) { room.seats[i] = human; sysChat(room, 'joined', { name: p.name }); }
    else room.spectators.add(pid);
  }
  broadcast(room); schedule(room);
  return i;
}

// ---------- اتصال‌ها ----------
io.on('connection', socket => {
  let pid = clean(socket.handshake.auth?.pid, 40);
  if (!pid || pid.length < 8) pid = crypto.randomUUID();
  socket.join('p:' + pid);
  let p = players.get(pid);
  if (!p) { p = { name: 'مهمان', avatar: AVATARS[crypto.randomInt(AVATARS.length)], room: null, sockets: new Set() }; players.set(pid, p); }
  p.sockets.add(socket.id);
  socket.emit('hello', { pid, name: p.name, avatar: p.avatar, room: p.room });

  // بازگشت خودکار به اتاق بعد از قطع اتصال
  if (p.room && rooms.has(p.room)) {
    const room = rooms.get(p.room);
    socket.join('r:' + room.code);
    const i = seatOf(room, pid);
    if (i >= 0) { room.seats[i].connected = true; room.seats[i].autoplay = false; room.seats[i].missed = 0; }
    socket.emit('chat_history', room.chat);
    broadcast(room); schedule(room);
  }

  const room = () => (p.room ? rooms.get(p.room) : null);
  const ok = (cb, data = {}) => typeof cb === 'function' && cb({ ok: true, ...data });
  const fail = (cb, error) => typeof cb === 'function' && cb({ ok: false, error });
  const on = (ev, fn) => socket.on(ev, (data, cb) => {
    try { fn(data || {}, cb); } catch (e) { fail(cb, e.message || 'error'); }
  });

  on('profile', ({ name, avatar }, cb) => {
    p.name = clean(name) || p.name;
    if (AVATARS.includes(avatar)) p.avatar = avatar;
    const r = room();
    if (r) { const i = seatOf(r, pid); if (i >= 0) { r.seats[i].name = p.name; r.seats[i].avatar = p.avatar; } broadcast(r); }
    ok(cb, { name: p.name, avatar: p.avatar });
  });

  on('create_room', ({ solo, isPublic, target, game }, cb) => {
    if (p.room) leaveRoom(pid);
    const r = createRoom(pid, { isPublic: !!isPublic && !solo, target, game });
    joinRoom(pid, r);
    if (solo) startGame(r);
    ok(cb, { code: r.code });
  });

  on('join_room', ({ code }, cb) => {
    const r = rooms.get(clean(code, 8).toUpperCase());
    if (!r) return fail(cb, 'room_not_found');
    const seat = joinRoom(pid, r);
    socket.emit('chat_history', r.chat);
    ok(cb, { code: r.code, seat });
  });

  on('quick_match', ({ game }, cb) => {
    let r = [...rooms.values()].find(x => x.isPublic && x.status === 'waiting' && x.seats.some(s => !s));
    if (!r) r = createRoom(pid, { isPublic: true, game });
    joinRoom(pid, r);
    socket.emit('chat_history', r.chat);
    ok(cb, { code: r.code });
  });

  on('public_rooms', (_, cb) => {
    ok(cb, {
      rooms: [...rooms.values()].filter(x => x.isPublic && x.status === 'waiting').slice(0, 20).map(x => ({
        code: x.code, game: x.game, players: humans(x).map(h => h.name), free: x.seats.filter(s => !s).length,
      })),
    });
  });

  on('leave_room', (_, cb) => { leaveRoom(pid); ok(cb); });

  on('take_seat', ({ seat }, cb) => {
    const r = room(); if (!r || r.status !== 'waiting') return fail(cb, 'bad_state');
    seat = +seat; if (!(seat >= 0 && seat < 4) || r.seats[seat]) return fail(cb, 'seat_taken');
    const i = seatOf(r, pid);
    const me = i >= 0 ? r.seats[i] : { kind: 'human', pid, name: p.name, avatar: p.avatar, connected: true };
    if (i >= 0) r.seats[i] = null; else r.spectators.delete(pid);
    r.seats[seat] = me;
    broadcast(r); ok(cb);
  });

  on('add_bot', ({ seat }, cb) => {
    const r = room(); if (!r || r.host !== pid || r.status !== 'waiting') return fail(cb, 'not_host');
    seat = +seat; if (r.seats[seat]) return fail(cb, 'seat_taken');
    r.seats[seat] = botSeat(r); broadcast(r); ok(cb);
  });

  on('clear_seat', ({ seat }, cb) => {
    const r = room(); if (!r || r.host !== pid || r.status !== 'waiting') return fail(cb, 'not_host');
    const s = r.seats[+seat]; if (!s) return ok(cb);
    if (s.kind === 'human') { if (s.pid === pid) return fail(cb, 'self'); r.spectators.add(s.pid); }
    r.seats[+seat] = null; broadcast(r); ok(cb);
  });

  on('settings', ({ target, isPublic }, cb) => {
    const r = room(); if (!r || r.host !== pid || r.status !== 'waiting') return fail(cb, 'not_host');
    if ([3, 5, 7, 10].includes(+target)) r.target = +target;
    if (typeof isPublic === 'boolean') r.isPublic = isPublic;
    broadcast(r); ok(cb);
  });

  on('start', (_, cb) => {
    const r = room(); if (!r || r.host !== pid) return fail(cb, 'not_host');
    if (r.status === 'playing') return fail(cb, 'already');
    if (r.status === 'finished') for (let i = 0; i < 4; i++) if (r.seats[i]?.vacated) r.seats[i] = botSeat(r);
    startGame(r); ok(cb);
  });

  on('back_to_lobby', (_, cb) => {
    const r = room(); if (!r || r.host !== pid || r.status === 'playing') return fail(cb, 'not_host');
    r.status = 'waiting'; r.engine = null;
    broadcast(r); ok(cb);
  });

  on('choose_trump', ({ suit }, cb) => {
    const r = room(); if (!r?.engine) return fail(cb, 'no_game');
    const i = seatOf(r, pid);
    r.engine.chooseTrump(i, suit);
    r.seats[i].missed = 0;
    broadcast(r); schedule(r); ok(cb);
  });

  on('play', ({ card }, cb) => {
    const r = room(); if (!r?.engine) return fail(cb, 'no_game');
    const i = seatOf(r, pid);
    r.engine.play(i, String(card));
    r.seats[i].missed = 0;
    broadcast(r); schedule(r); ok(cb);
  });

  on('autoplay', ({ value }, cb) => {
    const r = room(); if (!r) return fail(cb, 'no_room');
    const i = seatOf(r, pid); if (i < 0) return fail(cb, 'no_seat');
    r.seats[i].autoplay = !!value; r.seats[i].missed = 0;
    broadcast(r); schedule(r); ok(cb);
  });

  let lastChat = 0;
  on('chat', ({ text, emote }, cb) => {
    const r = room(); if (!r) return fail(cb, 'no_room');
    if (Date.now() - lastChat < 700) return fail(cb, 'slow');
    lastChat = Date.now();
    const msg = { name: p.name, avatar: p.avatar, seat: seatOf(r, pid), t: Date.now() };
    if (emote) msg.emote = clean(emote, 8); else msg.text = clean(text, 200);
    if (!msg.text && !msg.emote) return fail(cb, 'empty');
    r.chat.push(msg); if (r.chat.length > 60) r.chat.shift();
    io.to('r:' + r.code).emit('chat', msg); ok(cb);
  });

  socket.on('disconnect', () => {
    p.sockets.delete(socket.id);
    if (p.sockets.size) return;
    const r = room();
    if (!r) return;
    const i = seatOf(r, pid);
    if (i >= 0) {
      r.seats[i].connected = false;
      if (r.status === 'waiting') { // در اتاق انتظار، بعد از ۶۰ ثانیه جا آزاد می‌شود
        setTimeout(() => { if (!p.sockets.size && p.room === r.code) leaveRoom(pid); }, 60000);
      }
    }
    broadcast(r); schedule(r);
  });
});

// پاک‌سازی اتاق‌های رها‌شده
setInterval(() => {
  const now = Date.now();
  for (const [code, r] of rooms) {
    const anyone = humans(r).some(h => h.connected) || r.spectators.size;
    if (!anyone && now - r.lastActive > 15 * 60 * 1000) { clearTimeout(r.timer); rooms.delete(code); }
  }
  for (const [pid, p] of players) if (!p.sockets.size && (!p.room || !rooms.has(p.room))) players.delete(pid);
}, 60000);

server.listen(PORT, () => console.log('Dorehami running on :' + PORT));
module.exports = { server, rooms };
